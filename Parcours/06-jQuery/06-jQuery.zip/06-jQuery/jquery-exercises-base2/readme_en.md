# JQuery exercises - Part 2

**IMPORTANT**
All resources for exercises are provided.

## Exercise 1
At the click of the button, display a dialog box with the message of your choice.

## Exercise 2
At double click, change the width of the image to 500px;

## Exercise 3
Show or hide the text div at the click of the links provided.

## Exercise 4
At the click of a color button, change the color of the text of the div

## Exercise 5
When a field has the focus, set its border to "1px solid green". When the field loses focus, set the border to "1px solid red"

## Exercise 6
When moving the mouse over a colored button, color the text. The text should go black again when the mouse leaves the button.

## Exercise 7
Summary Exercise for Series 1 and 2. Instructions are in the HTML file.
