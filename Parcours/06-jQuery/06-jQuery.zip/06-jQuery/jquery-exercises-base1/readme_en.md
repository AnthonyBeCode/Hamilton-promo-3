# JQuery exercises

**IMPORTANT**

HTML and jQuery files are provided. **Warning**. As for Bootstrap, we do not modify the jQuery file.

## Exercise 1 :

Hide the div "texte".

## Exercise 2:

Display the "texte" div.

## Exercise 3:

Change the font-family of the div "texte" to "Courier".

## Exercise 4:

Change the color of all "li" tags to red

## Exercise 5:

Empty div "texte_2"

## Exercise 6:

Hide all items in the class "a_cacher".

## Exercise 7:

Delete all elements of the class "a_supprimer".

## Exercise 8:

Give all the elements "li" children of "ol" the red color.

## Exercise 9:

Give the div "texte_1" and "texte_3" a border of 5 pixels, green dotted ("5px green dashed").

## Exercise 10:

JQuery is already present and can hide all elements of the class "a_cacher". Add this class to the div "texte_3".
