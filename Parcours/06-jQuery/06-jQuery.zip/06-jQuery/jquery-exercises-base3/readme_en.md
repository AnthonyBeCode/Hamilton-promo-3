# Jquery Exercise - Part 3

**IMPORTANT**
You must use Jquery to do the exercises.

## Exercise 1
Build a html page with a button and a text field in which the number of clicks on the button is displayed.

## Exercise 2
Build an html page with a "+" button, a "-" button and a text field where you increase or decrease the number according to the clicked buttons.

## Exercise 3
Build an html page with a button and a text field. The goal is to find a number between 0 and 100. For each answer the page answers:
- more
- less
- correct

When the answer is found, we get the number of tests we did.

## Exercise 4
Build a html page with 5 buttons and a rectangle. Each button causes an action on the rectangle.
- Button 1: increases the height of 10px, if it exceeds 100px, it puts the height to 10px
- Button 2: puts the rectangle in green
- Button 3: restores the initial colors
- Button 4: makes the rectangle disappear
- Button 5: makes reappear the rectangle

## Exercise 5
Build an HTML page with a square and a text entry field in a form.
When you press a direction key the square moves 10 px in the right direction.
BONUS: When the block reaches one edge of the page, it must reappear on the other side.
